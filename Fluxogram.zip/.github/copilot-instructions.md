# Fluxogram: context for GitHub Copilot / AI agents

Fluxogram is a Telegram Android client built from the official open source
Telegram source (github.com/DrKLO/Telegram), rebranded and with a custom
liquid glass UI. All Telegram features come from the upstream source.

- App name: Fluxogram
- applicationId: com.fluxogram.app
- Java packages stay org.telegram.* (native JNI depends on them). Never rename them.

## How this repo works
This repo does NOT contain the Telegram source. The GitHub Action
.github/workflows/build-fluxogram.yml does this on each run:
1. clones the upstream Telegram source into ./telegram
2. runs scripts/patch.sh: sets applicationId, app name, api_id / api_hash
   (from secrets TG_API_ID and TG_API_HASH), and a placeholder google-services.json
3. copies overlay/ on top of the source (custom UI files)
4. builds the debug APK and uploads it as artifact Fluxogram-apk

## Where UI work goes
Put changed or new resource and source files in overlay/, using the same path
as in the Telegram source (e.g. overlay/TMessagesProj/src/main/res/...).
starter-ui/ is a small reference Android project showing the glass style
(translucent #26FFFFFF fill, 1dp #47FFFFFF stroke, 24dp radius, RenderEffect blur on API 31+).

## Rules
- Never commit api_id, api_hash or keystores. Use GitHub Secrets.
- Use only the owner's own api_id / api_hash from my.telegram.org.
- Do not use Telegram's name or logo as the app's branding.
- Do not spoof Premium or bypass server-side limits. Speed work means tuning
  parallel connections, chunk size and retries only.
- Telegram source is GPLv2: this project's source must remain public.
