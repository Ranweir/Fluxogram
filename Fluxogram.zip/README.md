# Fluxogram

Telegram-based Android app (package com.fluxogram.app). Context for AI agents: AGENTS.md

## Setup
1. my.telegram.org par login karke api_id aur api_hash banao.
2. Repo > Settings > Secrets and variables > Actions > New repository secret:
   - TG_API_ID
   - TG_API_HASH
3. Actions tab > "Build Fluxogram (Telegram fork)" > Run workflow.
4. Build khatam hone par Artifacts se Fluxogram-apk download karo.

## UI badalna
Files overlay/ folder me daalo (README.txt dekho).
