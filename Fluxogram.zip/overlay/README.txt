UI changes yahan rakho. Is folder ki files build ke time Telegram source ke upar copy hoti hain,
same path ke saath. Example: liquid glass drawable ke liye
  overlay/TMessagesProj/src/main/res/drawable/glass_bg.xml
Existing file ko badalna ho to uska poora updated version same path par rakho.
