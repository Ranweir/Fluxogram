#!/usr/bin/env bash
# Usage: scripts/patch.sh <telegram-source-dir>
# Rebrands the Telegram Android source as Fluxogram. Java packages (org.telegram.*)
# are NOT renamed on purpose: native JNI code depends on them.
set -euo pipefail
T="${1:?telegram dir}"
PKG="com.fluxogram.app"
NAME="Fluxogram"

: "${TG_API_ID:?Set secret TG_API_ID}"
: "${TG_API_HASH:?Set secret TG_API_HASH}"

# 1. applicationId
for f in $(grep -rlE 'applicationId' "$T" --include=build.gradle --include=build.gradle.kts); do
  sed -i -E "s/applicationId[ =]+\"[^\"]*\"/applicationId \"$PKG\"/" "$f"
  echo "applicationId patched in $f"
done

# 2. App name
for f in $(grep -rl 'name="AppName"' "$T" --include=strings.xml); do
  sed -i -E "s|(<string name=\"AppName\"[^>]*>)[^<]*(</string>)|\1$NAME\2|" "$f"
done

# 3. API keys
B=$(find "$T" -name BuildVars.java | head -1)
sed -i -E "s/APP_ID = [0-9]+;/APP_ID = ${TG_API_ID};/" "$B"
sed -i -E "s/APP_HASH = \"[^\"]*\"/APP_HASH = \"${TG_API_HASH}\"/" "$B"
echo "BuildVars patched: $B"

# 4. Placeholder google-services.json (push notifications will not work
#    until you replace it with your own Firebase file for $PKG)
for d in "$T/TMessagesProj_App" "$T/TMessagesProj"; do
  if [ -d "$d" ]; then
cat > "$d/google-services.json" <<JSON
{
  "project_info": {"project_number": "000000000000", "project_id": "fluxogram-placeholder", "storage_bucket": "fluxogram-placeholder.appspot.com"},
  "client": [{
    "client_info": {"mobilesdk_app_id": "1:000000000000:android:0000000000000000000000", "android_client_info": {"package_name": "$PKG"}},
    "oauth_client": [],
    "api_key": [{"current_key": "placeholder-key"}],
    "services": {"appinvite_service": {"other_platform_oauth_client": []}}
  }],
  "configuration_version": "1"
}
JSON
  fi
done

# 5. Your UI changes: anything in overlay/ is copied over the Telegram source
if [ -d overlay ] && [ "$(ls -A overlay | grep -v README || true)" ]; then
  cp -r overlay/. "$T/"
  rm -f "$T/README.md.overlay" || true
  echo "overlay applied"
fi
echo "Patch done"
