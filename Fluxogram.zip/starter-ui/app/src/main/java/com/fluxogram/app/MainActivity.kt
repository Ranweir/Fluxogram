package com.fluxogram.app

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val chats = listOf(
        "Saved Messages" to "Project_final.zip",
        "Rahul" to "Kal milte hain?",
        "Design Team" to "Naya mockup bheja hai",
        "Mummy" to "Khana kha liya?"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Liquid glass blur on background blobs (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val blur = RenderEffect.createBlurEffect(120f, 120f, Shader.TileMode.CLAMP)
            findViewById<View>(R.id.blobBlue).setRenderEffect(blur)
            findViewById<View>(R.id.blobPink).setRenderEffect(blur)
        }

        val list = findViewById<LinearLayout>(R.id.chatList)
        val dp = resources.displayMetrics.density
        chats.forEach { (name, last) ->
            val row = TextView(this).apply {
                text = "$name\n$last"
                setTextColor(0xFFEEF3FA.toInt())
                textSize = 16f
                setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
                setBackgroundResource(R.drawable.glass)
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (10 * dp).toInt() }
            list.addView(row, lp)
        }
    }
}
